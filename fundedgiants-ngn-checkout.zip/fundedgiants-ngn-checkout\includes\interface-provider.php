<?php
defined( 'ABSPATH' ) || exit;

/**
 * Interface Provider_Interface
 */
interface WC_Lenco_Provider_Interface {
    /**
     * Get the unique ID of the provider.
     * @return string
     */
    public function get_id();

    /**
     * Get the display name of the provider.
     * @return string
     */
    public function get_name();

    /**
     * Generate a virtual account for the order.
     *
     * @param WC_Order $order The WooCommerce order object.
     * @param float    $amount_ngn The amount in NGN to charge.
     * @return array|WP_Error Array with keys: bank_name, account_number, account_name, reference. Or WP_Error on failure.
     */
    public function generate_virtual_account( $order, $amount_ngn );

    /**
     * Verify a webhook request.
     *
     * @param WP_REST_Request $request
     * @return array|WP_Error Array with keys: status (paid/failed), amount, reference. Or WP_Error.
     */
    public function verify_webhook( $request );
    
    /**
     * Check if payment is confirmed (via API check).
     * 
     * @param string $reference
     * @return bool|WP_Error
     */
    public function confirm_payment( $reference );
}
