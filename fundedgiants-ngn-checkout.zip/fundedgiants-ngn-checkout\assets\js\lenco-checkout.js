jQuery(function($) {
    // Listen for the checkout_place_order_success event
    $('form.checkout').on('checkout_place_order_success', function(event, result) {
        if (result.lenco_open_modal) {
            // Stop redirection
            if (result.redirect) {
                // If there's a redirect functionality in WC we need to suppress it.
                // Usually returning false here isn't enough if internal WC handlers run.
                // But let's try to overwrite the behavior by simply not redirecting.
                // Actually, the Result object is passed. 
                
                // Open the Modal
                openLencoModal(result);
                
                // Return false to prevent WC from doing its default redirect
                return false; 
            }
        }
        return true;
    });

    function openLencoModal(data) {
        // Create Modal HTML if not exists
        if ($('#lenco-payment-modal').length === 0) {
            $('body').append(`
                <div id="lenco-payment-modal" class="lenco-modal-overlay">
                    <div class="lenco-modal-content">
                        <h3>Complete Your Payment via Bank Transfer</h3>
                        <p>Please make a one-time transfer of the exact amount to the account below.</p>
                        
                        <div class="lenco-account-details">
                            <div class="detail-row"><span class="label">Bank Name:</span> <span class="value bank-name"></span></div>
                            <div class="detail-row"><span class="label">Account Number:</span> <span class="value account-number"></span></div>
                            <div class="detail-row"><span class="label">Amount:</span> <span class="value amount"></span></div>
                        </div>

                        <div class="lenco-status">
                            <div class="spinner"></div>
                            <p>Waiting for payment confirmation...</p>
                        </div>
                        
                        <p class="lenco-note">Do not close this window. It will update automatically once payment is received.</p>
                    </div>
                </div>
            `);
        }

        // Populate Data
        $('#lenco-payment-modal .bank-name').text(data.bank_name);
        $('#lenco-payment-modal .account-number').text(data.account_number);
        $('#lenco-payment-modal .amount').text('\u20A6' + data.amount);
        
        // Show Modal
        $('#lenco-payment-modal').fadeIn();

        // Start Polling
        startPolling(data.order_id);
    }

    function startPolling(order_id) {
        var pollInterval = setInterval(function() {
            $.ajax({
                type: 'POST',
                url: lenco_params.ajax_url,
                data: {
                    action: 'lenco_check_payment_status',
                    order_id: order_id,
                    nonce: lenco_params.nonce
                },
                success: function(response) {
                    if (response.success && response.data.status === 'paid') {
                        clearInterval(pollInterval);
                        $('.lenco-status').html('<p style="color:green; font-weight:bold;">Payment Received! Redirecting...</p>');
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url;
                        }, 2000);
                    }
                }
            });
        }, 5000); // Check every 5 seconds
    }
});
