<?php
/**
 * Plugin Name: FundedGiants Checkout
 * Plugin URI: https://lenco.ng
 * Description: Accept one-time bank transfer payments in NGN using Lenco or Nomba.
 * Version: 2.4.0
 * Author: Favourable Esedeke
 * Text Domain: fundedgiants-ngn-checkout
 */

defined( 'ABSPATH' ) || exit;

define( 'WC_LENCO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// INCLUDE PROVIDER CLASSES
require_once WC_LENCO_PLUGIN_DIR . 'includes/interface-provider.php';
require_once WC_LENCO_PLUGIN_DIR . 'includes/class-lenco-provider.php';
require_once WC_LENCO_PLUGIN_DIR . 'includes/class-nomba-provider.php';
// require_once WC_LENCO_PLUGIN_DIR . 'includes/class-provider-router.php';

// 2. REGISTER GATEWAY
add_filter( 'woocommerce_payment_gateways', 'wc_lenco_add_gateway' );
function wc_lenco_add_gateway( $gateways ) {
    $gateways[] = 'WC_Lenco_Gateway';
    return $gateways;
}

// 3. GATEWAY CLASS (INLINE)
add_action( 'plugins_loaded', 'wc_lenco_init_class', 11 );
function wc_lenco_init_class() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

    class WC_Lenco_Gateway extends WC_Payment_Gateway {
        public $bearer_token;
        public $nomba_client_id;
        public $nomba_private_key;
        public $nomba_account_id;
        public $nomba_environment;
        public $api_key;
        public $ipn_secret;
        public $environment;

        public function __construct() {
            $this->id                 = 'lenco_payment';
            $this->method_title       = __( 'FundedGiants Checkout', 'fundedgiants-ngn-checkout' );
            $this->method_description = __( 'Accept NGN payments via dynamic virtual accounts (Lenco / Nomba).', 'fundedgiants-ngn-checkout' );
            $this->icon               = ''; 
            $this->has_fields         = false;

            // Declare properties to avoid warnings
            $this->bearer_token       = '';
            $this->nomba_client_id    = '';
            $this->nomba_private_key   = '';
            $this->nomba_account_id   = '';
            $this->nomba_environment  = '';

            $this->init_form_fields();
            $this->init_settings();

            $this->title        = $this->get_option( 'title' );
            $this->description  = $this->get_option( 'description' );
            $this->enabled      = $this->get_option( 'enabled' );
            
            // Lenco
            $this->bearer_token = $this->get_option( 'bearer_token' );
            
            // Nomba
            $this->nomba_client_id = $this->get_option( 'nomba_client_id' );
            $this->nomba_private_key = $this->get_option( 'nomba_private_key' );
            $this->nomba_account_id = $this->get_option( 'nomba_account_id' );
            $this->nomba_environment = $this->get_option( 'nomba_environment' );

            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
            add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array( 'title' => 'Enable/Disable', 'type' => 'checkbox', 'label' => 'Enable', 'default' => 'yes' ),
                'active_provider' => array(
                    'title'       => 'Active Provider',
                    'type'        => 'select',
                    'options'     => array(
                        'lenco' => 'Lenco',
                        'nomba' => 'Nomba',
                    ),
                    'default'     => 'nomba',
                    'description' => 'Select which provider handles the payments.',
                ),
                'title' => array( 'title' => 'Title', 'type' => 'text', 'default' => 'Bank Transfer' ),
                'description' => array( 'title' => 'Description', 'type' => 'textarea', 'default' => 'Transfer the exact amount to complete the order.' ),
                

                'section_lenco' => array( 'title' => 'Lenco Settings', 'type' => 'title', 'description' => 'Webhook URL: <code>' . site_url('/wp-json/lenco/v1/webhook') . '</code>' ),
                'bearer_token' => array( 'title' => 'Lenco Bearer Token', 'type' => 'password', 'default' => '' ),
                
                'section_nomba' => array( 'title' => 'Nomba Settings', 'type' => 'title', 'description' => 'Configure your Nomba merchant details.' ),
                'nomba_webhook_url' => array(
                    'title'       => 'Nomba Webhook URL',
                    'type'        => 'text',
                    'default'     => site_url('/wp-json/nomba/v1/webhook'),
                    'description' => 'Copy this URL into your Nomba Dashboard.',
                    'custom_attributes' => array( 'readonly' => 'readonly' )
                ),
                'nomba_client_id' => array(
                    'title'       => 'Nomba Client ID',
                    'type'        => 'text',
                    'default'     => '',
                    'description' => defined( 'NOMBA_CLIENT_ID' ) ? '🔒 <em>Managed securely via NOMBA_CLIENT_ID constant in wp-config.php.</em>' : 'Found in your Nomba Dashboard under API Keys.',
                    'custom_attributes' => defined( 'NOMBA_CLIENT_ID' ) ? array( 'disabled' => 'disabled' ) : array(),
                ),
                'nomba_private_key' => array(
                    'title'       => 'Nomba Private Key (Client Secret)',
                    'type'        => 'password',
                    'default'     => '',
                    'description' => defined( 'NOMBA_PRIVATE_KEY' ) ? '🔒 <em>Managed securely via NOMBA_PRIVATE_KEY constant in wp-config.php.</em>' : 'Your Nomba Private Key — masked and handled securely.',
                    'custom_attributes' => defined( 'NOMBA_PRIVATE_KEY' ) ? array( 'disabled' => 'disabled' ) : array(),
                ),
                'nomba_account_id' => array(
                    'title'       => 'Nomba Account ID',
                    'type'        => 'text',
                    'default'     => '',
                    'description' => defined( 'NOMBA_ACCOUNT_ID' ) ? '🔒 <em>Managed securely via NOMBA_ACCOUNT_ID constant in wp-config.php.</em>' : 'The accountId tied to your API keys in the Nomba Dashboard.',
                    'custom_attributes' => defined( 'NOMBA_ACCOUNT_ID' ) ? array( 'disabled' => 'disabled' ) : array(),
                ),
                'nomba_webhook_secret' => array( 
                    'title'       => 'Nomba Webhook Secret', 
                    'type'        => 'password', 
                    'default'     => '', 
                    'description' => defined( 'NOMBA_WEBHOOK_SECRET' ) ? '🔒 <em>Managed securely via NOMBA_WEBHOOK_SECRET constant in wp-config.php.</em>' : 'Provided in Nomba Dashboard under Webhooks.',
                    'custom_attributes' => defined( 'NOMBA_WEBHOOK_SECRET' ) ? array( 'disabled' => 'disabled' ) : array(),
                ),
                'nomba_environment' => array(
                    'title'   => 'Environment',
                    'type'    => 'select',
                    'default' => 'live',
                    'options' => array(
                        'sandbox' => 'Sandbox',
                        'live'    => 'Live'
                    ),
                    'description' => defined( 'NOMBA_ENVIRONMENT' ) ? '🔒 <em>Managed securely via NOMBA_ENVIRONMENT constant in wp-config.php.</em>' : 'Select Live or Sandbox.',
                    'custom_attributes' => defined( 'NOMBA_ENVIRONMENT' ) ? array( 'disabled' => 'disabled' ) : array(),
                ),
            );
        }

        public function is_available() { return true; }

        private function get_provider_instance( $slug ) {
            switch ( $slug ) {
                case 'lenco':
                    return new WC_Lenco_Provider( 
                        $this->get_option('bearer_token') 
                    );
                case 'nomba':
                default:
                    $client_id     = defined( 'NOMBA_CLIENT_ID' ) ? NOMBA_CLIENT_ID : $this->get_option( 'nomba_client_id' );
                    $client_secret = defined( 'NOMBA_PRIVATE_KEY' ) ? NOMBA_PRIVATE_KEY : $this->get_option( 'nomba_private_key' );
                    $account_id    = defined( 'NOMBA_ACCOUNT_ID' ) ? NOMBA_ACCOUNT_ID : $this->get_option( 'nomba_account_id' );
                    $environment   = defined( 'NOMBA_ENVIRONMENT' ) ? NOMBA_ENVIRONMENT : $this->get_option( 'nomba_environment', 'live' );
                    $webhook_sec   = defined( 'NOMBA_WEBHOOK_SECRET' ) ? NOMBA_WEBHOOK_SECRET : $this->get_option( 'nomba_webhook_secret' );

                    return new WC_Nomba_Provider(
                        $client_id,
                        $client_secret,
                        $account_id,
                        $environment,
                        $webhook_sec
                    );
            }
        }

        public function payment_scripts() {
            // Support Checkout, Order Pay, Orchestrator pages, and Received pages
            $is_orchestrator = class_exists( 'FG_Checkout_Orchestrator' ) && FG_Checkout_Orchestrator::is_orchestrator_page();
            if ( ! is_checkout() && ! is_checkout_pay_page() && ! is_order_received_page() && ! $is_orchestrator ) return;
            $this->enqueue_scripts();
        }
        
        private function enqueue_scripts() {
             // 1. Disable PHP Auto-Open to ensure user clicks pay first
             $auto_open_data = false;
             
             // INLINE CSS FOR PREMIUM DARK UI
            $css = <<<'EOD'
                /* Fonts */
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

                #lenco-modal { display:none; position:fixed; z-index:999999; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.85); backdrop-filter: blur(5px); overflow-y: auto; }
                
                .lenco-content { 
                    background: #111214; 
                    color: #fff;
                    margin: 5vh auto; 
                    width: 95%; 
                    max-width: 530px; 
                    display: flex;
                    flex-direction: column;
                    border-radius: 12px; 
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7); 
                    border: 1px solid #2a2b2d;
                    overflow: hidden;
                    position: relative;
                    animation: lencoSlideIn 0.3s ease-out;
                }
                @keyframes lencoSlideIn { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

                /* Header */
                .lenco-header { padding: 8px 20px; border-bottom: 1px solid #222; display: flex; justify-content: space-between; align-items: flex-start; }
                .lenco-header-icon { font-size: 20px; margin-right: 12px; color: #00e676; flex-shrink: 0; }
                .lenco-title h3 { margin: 0; font-size: 15px; color: #fff; font-weight: 600; line-height: 1.4; }
                .lenco-title p { margin: 1px 0 0; font-size: 12px; color: #888; }
                .lenco-close { cursor: pointer; color: #666; font-size: 24px; line-height: 1; transition: 0.2s; }
                .lenco-close:hover { color: #fff; }

                /* Body */
                .lenco-body { padding: 10px 20px 20px 20px; overflow-y: auto; }
                
                /* Amount Box */
                .lenco-amount-box { 
                    background: #1a1c1e; 
                    border: 1px solid #333; 
                    border-radius: 8px; 
                    padding: 8px 12px 10px; 
                    text-align: center; 
                    margin-bottom: 8px; 
                }
                .lenco-lbl { font-size: 11px; color: #888; letter-spacing: 0.8px; text-transform: uppercase; font-weight: 600; line-height: 1.2; }
                .lenco-big-amt { font-size: 28px; font-weight: 700; color: #00e676; margin: 2px 0 0; letter-spacing: -0.5px; line-height: 1.15; }
                .lenco-sub-amt, #lenco-usd-amt { display: none !important; }

                /* Instruction */
                .lenco-instr-line { 
                    font-size: 14px; 
                    font-weight: 500; 
                    color: #d1d5db; 
                    margin: 0 0 8px 0; 
                    display: flex; 
                    align-items: center; 
                    gap: 8px; 
                    line-height: 1.35; 
                    width: 100%; 
                    box-sizing: border-box; 
                }
                .lenco-instr-icon { color: #00e676; flex-shrink: 0; display: inline-flex; align-items: center; }
                .lenco-instr-line span:last-child { flex: 1; display: inline; }
                #lenco-ngn-amt { color: #fff; font-weight: 700; }

                /* Data Rows */
                .lenco-data-group { margin-bottom: 8px; }
                .lenco-data-row { 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center; 
                    background: #18191b; 
                    border: 1px solid #2a2b2d; 
                    padding: 11px 14px; 
                    margin-bottom: 8px; 
                    border-radius: 6px;
                    gap: 12px;
                    transition: 0.2s;
                }
                .lenco-data-row:hover { border-color: #444; background: #1e1f21; }
                .lenco-key { font-size: 13px; color: #9ca3af; font-weight: 500; white-space: nowrap !important; flex-shrink: 0; }
                .lenco-val-grp { display: flex; align-items: center; justify-content: flex-end; gap: 8px; flex: 1; min-width: 0; }
                .lenco-data-val { font-size: 14px; font-weight: 600; color: #fff; text-align: right; user-select: text; word-break: break-word; }
                
                /* SPECIAL STYLE ONLY FOR ACCOUNT NUMBER */
                .lenco-acc-num-val { font-size: 18px !important; letter-spacing: 1px !important; font-family: 'Courier New', monospace !important; color: #00e676 !important; font-weight: 700 !important; }

                .lenco-copy-btn { 
                    cursor: pointer; 
                    color: #00e676; /* Green Copy Icon */
                    font-size: 16px; 
                    background: none; 
                    border: none; 
                    padding: 0;
                    line-height: 1;
                    display: flex;
                    align-items: center;
                    opacity: 0.9;
                }
                .lenco-copy-btn:hover { opacity: 1; transform: scale(1.1); }

                /* Footer Indicators */
                /* Footer Indicators */
                /* Footer Indicators */
                /* Footer Indicators */
                .lenco-status { text-align: center; font-size: 13px; color: #bbb; margin: 4px 0 4px; display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 500; }
                .lenco-dot { width: 6px; height: 6px; background: #ffbc00; border-radius: 50%; display: inline-block; animation: Pulse 2s infinite; box-shadow: 0 0 8px #ffbc00; }
                .lenco-timer-span { color: #ffbc00; font-family: monospace; font-weight: bold; }

                .lenco-secure-badge { 
                    background: rgba(0, 230, 118, 0.08); 
                    border: 1px solid rgba(0, 230, 118, 0.15); 
                    color: #00e676; 
                    padding: 8px; 
                    border-radius: 6px; 
                    font-size: 13px; 
                    text-align: center; 
                    line-height: 1.5;
                    display: flex; align-items: center; justify-content: center; gap: 8px;
                }
                .lenco-lock { font-size: 14px; }

                @keyframes Pulse { 0% { opacity: 1; transform: scale(1); } 50% { opacity: 0.5; transform: scale(0.8); } 100% { opacity: 1; transform: scale(1); } }
                
                /* Selection Buttons REMOVED */
                
                /* Mobile */
                @media(max-width: 600px) {
                    .lenco-content { width: 95%; margin: 2vh auto; border-radius: 12px; max-height: 96vh; }
                    .lenco-body { padding: 15px; }
                    .lenco-big-amt { font-size: 24px; }
                    .lenco-instr-line { font-size: 13.5px; }
                    .lenco-instr-line span:last-child { white-space: normal; }
                }
EOD;

            wp_register_style( 'lenco-styles', false );
            wp_enqueue_style( 'lenco-styles' );
            wp_add_inline_style( 'lenco-styles', $css );

            // COPY SCRIPT & LOGIC using Heredoc
            $js = <<<EOD
                jQuery(function($){
                    // HTML TEMPLATE
                    var modalHtml = `
                    <div id='lenco-modal'>
                        <div class='lenco-content'>
                            <div class='lenco-header'>
                                <div style='display:flex;'>
                                    <div class='lenco-header-icon'>
                                        <svg width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M3 21h18M5 21V7l8-4 8 4v14M10 10v4M14 10v4'/></svg>
                                    </div> 
                                    <div class='lenco-title'>
                                        <h3>Automated NGN Bank Transfer</h3>
                                        <p>Complete your payment securely</p>
                                    </div>
                                </div>
                                <div class='lenco-close' id='lenco-force-close'>&times;</div>
                            </div>
                            <div class='lenco-body'>
                                <!-- Details Screen (Always Visible) -->
                                <div id='lenco-details-screen'>
                                    <div class='lenco-amount-box'>
                                        <div class='lenco-lbl'>TOTAL AMOUNT</div>
                                        <div id='lenco-top-amt' class='lenco-big-amt'></div>
                                    </div>

                                    <div class='lenco-instr-line'>
                                        <span class='lenco-instr-icon'><svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='#00e676' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><polyline points='20 6 9 17 4 12'/></svg></span>
                                        <span>Transfer exactly <strong id="lenco-ngn-amt"></strong> to this account:</span>
                                    </div>

                                    <div id='lenco-rows' class='lenco-data-group'></div>

                                    <div class='lenco-status'>
                                        <span class='lenco-dot'></span> Waiting for payment... <span id="lenco-timer" class="lenco-timer-span">59:59</span>
                                    </div>

                                    <div class='lenco-secure-badge'>
                                        <span class='lenco-lock'><svg width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='#00e676' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='3' y='11' width='18' height='11' rx='2' ry='2'></rect><path d='M7 11V7a5 5 0 0 1 10 0v4'></path></svg></span> 
                                        <span>Your payment will be automatically verified and your account activated immediately upon verification.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;

                    if($('#lenco-modal').length === 0) $('body').append(modalHtml);

                    // AUTO OPEN CHECK
                    if ( typeof lenco_params !== 'undefined' && lenco_params.auto_open ) {
                        fillDetails( lenco_params.auto_open );
                        $('#lenco-modal').fadeIn();
                    }

                    // COPY FUNCTION
                    window.lencoCopy = function(text, btn) {
                        navigator.clipboard.writeText(text).then(function(){
                            var original = $(btn).html();
                            $(btn).html('<svg width=\"16\" height=\"16\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#00e676\" stroke-width=\"2.5\"><polyline points=\"20 6 9 17 4 12\"/></svg>').css('color', '#00e676');
                            setTimeout(function(){ $(btn).html(original).css('color', ''); }, 1500);
                        });
                    };

                    var currentOrder = null;
                    var loopTimer = null;
                    var pollTimer = null;

                    // EXPOSE MODAL OPEN FUNCTION GLOBALLY
                    window.lencoOpenModal = function(data) {
                        if($('#lenco-modal').length === 0) $('body').append(modalHtml);
                        fillDetails(data);
                        $('#lenco-modal').fadeIn();
                    };

                    // DETECT URL PARAM FOR AUTO-OPEN
                    const urlParams = new URLSearchParams(window.location.search);
                    if ( urlParams.has('lenco_modal') && typeof lenco_params !== 'undefined' && lenco_params.auto_open ) {
                        fillDetails( lenco_params.auto_open );
                        $('#lenco-modal').fadeIn();
                    }

                    $('form.checkout, form#order_review').on('checkout_place_order_success', function(e, result){
                        console.log('Checkout Response:', result);
                        
                        if ( result.lenco_modal ) {
                            currentOrder = { 
                                id: result.order_id, 
                                key: result.order_key, 
                                amt: result.amt 
                            };
                            
                            fillDetails(result);
                            $('#lenco-modal').fadeIn();
                            return false; 
                        }
                    });

                    function fillDetails(data) {
                        var nairaSign = '\u20A6';
                        $('#lenco-ngn-amt').text(nairaSign + data.amt);
                        $('#lenco-top-amt').text(nairaSign + data.amt);

                        var fields = [
                            { k: 'Bank Name:', v: data.bank, isAcc: false },
                            { k: 'Account Name:', v: data.acc_name, isAcc: false },
                            { k: 'Account Number:', v: data.acc, isAcc: true },
                            { k: 'Reference:', v: data.ref, isAcc: false }
                        ];

                        var rows = '';
                        var copyIcon = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path></svg>`;

                        fields.forEach(function(f){
                            var valClass = f.isAcc ? 'lenco-data-val lenco-acc-num-val' : 'lenco-data-val';
                            rows += `
                            <div class='lenco-data-row'>
                                <span class='lenco-key'>\${f.k}</span>
                                <div class='lenco-val-grp'>
                                     <span class='\${valClass}'>\${f.v}</span>
                                     <button class='lenco-copy-btn' onclick='lencoCopy("\${f.v}", this)' type='button' title='Copy'>\${copyIcon}</button>
                                </div>
                            </div>`;
                        });
                        $('#lenco-rows').html(rows);

                        // START TIMERS
                        if(loopTimer) clearInterval(loopTimer);
                        var duration = 60 * 60;
                        loopTimer = setInterval(function() {
                            var mins = parseInt(duration / 60, 10);
                            var secs = parseInt(duration % 60, 10);
                            $('#lenco-timer').text((mins<10?'0':'')+mins + ':' + (secs<10?'0':'')+secs);
                            if (--duration < 0) { clearInterval(loopTimer); $('#lenco-timer').text('EXPIRED'); }
                        }, 1000);

                        if(pollTimer) clearInterval(pollTimer);
                        var ajaxUrl = (typeof lenco_params !== 'undefined' && lenco_params.ajax_url)
                            ? lenco_params.ajax_url
                            : (typeof wc_checkout_params !== 'undefined' ? wc_checkout_params.ajax_url : '/wp-admin/admin-ajax.php');
                        var nonce = (typeof lenco_params !== 'undefined' && lenco_params.nonce) ? lenco_params.nonce : '';

                        pollTimer = setInterval(function(){
                            $.post(ajaxUrl, {
                                action: 'lenco_check_status',
                                order_id: data.order_id,
                                order_key: data.order_key,
                                security: nonce
                            }, function(res){
                                if(res.success && res.data.status === 'paid'){
                                    clearInterval(pollTimer);
                                    window.location.href = res.data.url;
                                }
                            });
                        }, 5000);
                    }

                    $('#lenco-force-close').on('click', function(){
                        if(confirm('Cancel payment?')) {
                            $('#lenco-modal').fadeOut();
                            $('#place_order').removeClass('processing').text('Pay Now →').css({'opacity': '1', 'pointer-events': 'auto'});
                            var \$checkoutForm = $('form.checkout, form#fg-billing-form');
                            if (\$checkoutForm.length) {
                                \$checkoutForm.removeClass('processing');
                                if (typeof \$checkoutForm.unblock === 'function') \$checkoutForm.unblock();
                            }
                        }
                    });
                });
EOD;

            wp_register_script( 'lenco-js', false, array( 'jquery' ) );
            wp_enqueue_script( 'lenco-js' );
            wp_add_inline_script( 'lenco-js', $js );

            // LOCALIZE NONCE & AUTO OPEN DATA
            wp_localize_script( 'lenco-js', 'lenco_params', array(
                'ajax_url'  => admin_url( 'admin-ajax.php' ),
                'nonce'     => wp_create_nonce( 'lenco_payment_nonce' ),
                'auto_open' => $auto_open_data 
            ));
        }

        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                return array(
                    'result'  => 'failure',
                    'refresh' => 'false',
                    'message' => 'Order not found.'
                );
            }
            
            // 1. Calculate Amount in NGN (Store currency is 100% NGN)
            $ngn_amount = round( (float) $order->get_total(), 2 );

            // 2. Select Active Provider & Generate Dynamic One-Time Virtual Account
            $settings = get_option( 'woocommerce_lenco_payment_settings' );
            $active_slug = $settings['active_provider'] ?? 'nomba';
            
            // Instantiate provider directly
            $provider = $this->get_provider_instance( $active_slug );
            
            // Generate Account
            $result = $provider->generate_virtual_account( $order, $ngn_amount );

            if ( is_wp_error( $result ) ) {
                $err_msg = $result->get_error_message();
                wc_add_notice( 'Payment Error: ' . $err_msg, 'error' );
                return array(
                    'result'  => 'failure',
                    'refresh' => 'false',
                    'message' => $err_msg
                );
            }

            // Save Meta to Order
            $order->update_meta_data( '_lenco_bank_name', $result['bank_name'] );
            $order->update_meta_data( '_lenco_account_number', $result['account_number'] );
            $order->update_meta_data( '_lenco_account_name', $result['account_name'] ); 
            $order->update_meta_data( '_lenco_reference', $result['reference'] );
            $order->update_meta_data( '_lenco_amount_ngn', $ngn_amount );
            $order->update_meta_data( '_bank_provider', $provider->get_id() );
            $order->save();

            // Return success with direct modal trigger payload
            $redirect_url = $order->get_checkout_payment_url( true );
            $redirect_url = add_query_arg( 'lenco_modal', 'true', $redirect_url );

            return array(
                'result'      => 'success',
                'redirect'    => $redirect_url,
                'lenco_modal' => true,
                'order_id'    => $order_id,
                'order_key'   => $order->get_order_key(), 
                'bank'        => $result['bank_name'],
                'acc'         => $result['account_number'],
                'acc_name'    => $result['account_name'],
                'ref'         => $result['reference'],
                'amt'         => number_format( $ngn_amount, 2 )
            );
        }

        public function thankyou_page( $order_id ) {
            $order = wc_get_order( $order_id );
            $bank = $order->get_meta( '_lenco_bank_name' );
            $acc = $order->get_meta( '_lenco_account_number' );
            if($bank) echo "<div class='woocommerce-message'><h3>Paid to: " . esc_html( $bank ) . " - " . esc_html( $acc ) . "</h3></div>";
        }
    }
}

// 4. AJAX POLL HANDLER
add_action( 'wp_ajax_lenco_check_status', 'wc_lenco_check_status' );
add_action( 'wp_ajax_nopriv_lenco_check_status', 'wc_lenco_check_status' );

function wc_lenco_check_status() {
    check_ajax_referer( 'lenco_payment_nonce', 'security' );

    $order_id = intval( $_POST['order_id'] );
    $order_key = sanitize_text_field( $_POST['order_key'] );
    
    $order = wc_get_order( $order_id );

    // SECURITY CHECK: Verify Order Key to prevent ID Enumeration
    if ( ! $order || $order->get_order_key() !== $order_key ) {
        wp_send_json_error( array( 'message' => 'Invalid Security Token' ) );
        return;
    }

    if ( $order->has_status( array('processing','completed') ) ) {
        wp_send_json_success( array( 'status' => 'paid', 'url' => $order->get_checkout_order_received_url() ) );
    }
    wp_send_json_error();
}

// 5. WEBHOOK HANDLER
add_action( 'rest_api_init', function() {
    register_rest_route( 'lenco/v1', '/webhook', array(
        'methods'  => 'POST',
        'callback' => 'wc_lenco_handle_webhook',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route( 'nomba/v1', '/webhook', array(
        'methods'  => 'POST',
        'callback' => 'wc_lenco_handle_webhook', 
        'permission_callback' => '__return_true',
    ));
});

function wc_lenco_handle_webhook( $request ) {
    $settings = get_option( 'woocommerce_lenco_payment_settings' );
    
    $provider = null;
    $sig_lenco = $request->get_header( 'x-lenco-signature' );
    $sig_nomba = $request->get_header( 'nomba-signature' ) 
              ?: $request->get_header( 'x-nomba-signature' ) 
              ?: $request->get_header( 'nomba-sig-value' );
    $route     = $request->get_route();
    $proxy_hdr = $request->get_header( 'x-nomba-proxy' );
    $body_raw  = $request->get_body();
    $body_json = json_decode( $body_raw, true );

    // Check if Nomba payload indicators or headers exist
    $is_nomba = $sig_nomba 
             || strpos( $route, 'nomba' ) !== false 
             || $proxy_hdr === 'FundedGiants-Internal'
             || ! empty( $body_json['data']['transaction']['aliasAccountReference'] )
             || ! empty( $body_json['data']['accountRef'] )
             || ! empty( $body_json['data']['merchant'] )
             || ! empty( $body_json['event_type'] );

    if ( $is_nomba ) {
        $client_id     = defined( 'NOMBA_CLIENT_ID' ) ? NOMBA_CLIENT_ID : ( $settings['nomba_client_id'] ?? '' );
        $client_secret = defined( 'NOMBA_PRIVATE_KEY' ) ? NOMBA_PRIVATE_KEY : ( $settings['nomba_private_key'] ?? '' );
        $account_id    = defined( 'NOMBA_ACCOUNT_ID' ) ? NOMBA_ACCOUNT_ID : ( $settings['nomba_account_id'] ?? '' );
        $environment   = defined( 'NOMBA_ENVIRONMENT' ) ? NOMBA_ENVIRONMENT : ( $settings['nomba_environment'] ?? 'live' );
        $webhook_sec   = defined( 'NOMBA_WEBHOOK_SECRET' ) ? NOMBA_WEBHOOK_SECRET : ( $settings['nomba_webhook_secret'] ?? '' );

        $provider = new WC_Nomba_Provider(
            $client_id,
            $client_secret,
            $account_id,
            $environment,
            $webhook_sec
        );
    } elseif ( $sig_lenco || strpos( $route, 'lenco' ) !== false ) {
        $provider = new WC_Lenco_Provider( 
            $settings['bearer_token'] ?? '' 
        );
    } else {
        // Fallback default: Nomba
        $client_id     = defined( 'NOMBA_CLIENT_ID' ) ? NOMBA_CLIENT_ID : ( $settings['nomba_client_id'] ?? '' );
        $client_secret = defined( 'NOMBA_PRIVATE_KEY' ) ? NOMBA_PRIVATE_KEY : ( $settings['nomba_private_key'] ?? '' );
        $account_id    = defined( 'NOMBA_ACCOUNT_ID' ) ? NOMBA_ACCOUNT_ID : ( $settings['nomba_account_id'] ?? '' );
        $environment   = defined( 'NOMBA_ENVIRONMENT' ) ? NOMBA_ENVIRONMENT : ( $settings['nomba_environment'] ?? 'live' );
        $webhook_sec   = defined( 'NOMBA_WEBHOOK_SECRET' ) ? NOMBA_WEBHOOK_SECRET : ( $settings['nomba_webhook_secret'] ?? '' );

        $provider = new WC_Nomba_Provider(
            $client_id,
            $client_secret,
            $account_id,
            $environment,
            $webhook_sec
        );
    }

    $result = $provider->verify_webhook( $request );

    if ( is_wp_error( $result ) ) {
        return new WP_REST_Response( array( 'status' => 'error', 'message' => $result->get_error_message() ), 400 );
    }

    // Success
    $ref = $result['reference'];
    $order_id = 0;
    
    if ( strpos( $ref, 'lco' ) === 0 ) {
        $temp = substr( $ref, 3 );
        if ( strlen( $temp ) > 6 ) {
             $order_id = intval( substr( $temp, 0, -6 ) );
        } else {
             $order_id = intval( $temp ); 
        }
    } elseif ( strpos( $ref, 'NMB' ) === 0 ) {
        $temp = substr( $ref, 3 );
        if ( strpos( $temp, 'T' ) !== false ) {
            $parts = explode( 'T', $temp );
            $order_id = intval( $parts[0] );
        } else {
            $order_id = intval( $temp );
        }
    } else {
        $order_id = intval( $ref );
    }

    $order = $order_id ? wc_get_order( $order_id ) : null;
    if ( ! $order && ! empty( $result['account_number'] ) ) {
        $orders = wc_get_orders( array(
            'limit'      => 1,
            'status'     => array( 'pending', 'on-hold' ),
            'meta_key'   => '_lenco_account_number',
            'meta_value' => $result['account_number'],
            'orderby'    => 'date',
            'order'      => 'DESC',
        ) );
        if ( ! empty( $orders ) ) {
            $order = $orders[0];
            $order_id = $order->get_id();
        }
    }

    if ( $order ) {
        // IDEMPOTENCY GUARD: Check if this specific payment reference has already been processed to prevent replay attacks
        $processed_refs = (array) $order->get_meta( '_fg_processed_webhook_refs' );
        if ( ! empty( $ref ) && in_array( $ref, $processed_refs, true ) ) {
            return new WP_REST_Response( array( 'status' => 'ok', 'message' => 'Duplicate webhook ignored' ), 200 );
        }

        $received_amount = (float) $result['amount'];
        $order_total_ngn = (float) $order->get_meta( '_lenco_amount_ngn' );
        if ( $order_total_ngn <= 0 ) {
            $order_total_ngn = (float) $order->get_total();
        }
        $user_id = $order->get_user_id();

        if ( ! $order->has_status( 'completed' ) ) {
            if ( $received_amount < $order_total_ngn ) {
                // UNDERPAYMENT: Mark on-hold, pause provisioning, prompt user to complete payment or contact admin
                $deficit = $order_total_ngn - $received_amount;
                $order->update_meta_data( '_fg_amount_received', $received_amount );
                $order->update_meta_data( '_fg_underpaid_deficit', $deficit );
                $order->update_status( 'on-hold', sprintf(
                    'Underpayment received: ₦%s of ₦%s (Outstanding balance: ₦%s). Trading account provisioning is paused. Please complete your payment or contact FundedGiants Support at support@fundedgiants.ng for assistance.',
                    number_format( $received_amount, 2 ),
                    number_format( $order_total_ngn, 2 ),
                    number_format( $deficit, 2 )
                ) );
            } else {
                // EXACT OR OVERPAYMENT: Mark overage, complete order, and trigger CRM dashboard provisioning
                $excess = $received_amount > $order_total_ngn ? round( $received_amount - $order_total_ngn, 2 ) : 0.00;
                $order->update_meta_data( '_fg_amount_received', $received_amount );
                $order->update_meta_data( '_fg_overpayment_amount', $excess );
                $order->payment_complete();

                if ( $excess > 0 ) {
                    $order->add_order_note( sprintf(
                        'Overpayment received via %s: ₦%s (Required: ₦%s). Overage difference of ₦%s recorded and transmitted via webhook to CRM trader dashboard balance.',
                        $provider->get_name(),
                        number_format( $received_amount, 2 ),
                        number_format( $order_total_ngn, 2 ),
                        number_format( $excess, 2 )
                    ) );
                } else {
                    $order->add_order_note( sprintf( 'Paid via %s. Received exact amount: ₦%s', $provider->get_name(), number_format( $received_amount, 2 ) ) );
                }
            }

            // Record reference in idempotency ledger
            if ( ! empty( $ref ) ) {
                $processed_refs[] = $ref;
                $order->update_meta_data( '_fg_processed_webhook_refs', array_values( array_unique( $processed_refs ) ) );
                $order->save();
            }
        }
    }
    return new WP_REST_Response( array( 'status' => 'ok' ), 200 );
}
?>
