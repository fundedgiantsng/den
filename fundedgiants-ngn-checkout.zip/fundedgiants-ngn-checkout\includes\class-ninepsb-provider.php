<?php
defined( 'ABSPATH' ) || exit;

class WC_NinePSB_Provider implements WC_Lenco_Provider_Interface {
    private $public_key;
    private $private_key;
    private $webhook_username;
    private $webhook_password;

    public function __construct( $public_key, $private_key, $webhook_username = '', $webhook_password = '' ) {
        $this->public_key = $public_key;
        $this->private_key = $private_key;
        $this->webhook_username = $webhook_username;
        $this->webhook_password = $webhook_password;
    }

    public function get_id() {
        return '9psb';
    }

    public function get_name() {
        return '9PSB';
    }

    /**
     * Authenticate and get Access Token
     * Uses Public/Private Key as per Postman Collection
     */
    private function get_access_token() {
        $token = get_transient( 'wc_9psb_access_token' );
        if ( $token ) return $token;

        $base_url = 'https://baastest.9psb.com.ng';
        $endpoint = "$base_url/iva-api/v1/merchant/virtualaccount/authenticate";

        $body = array(
            'publickey' => $this->public_key,
            'privatekey' => $this->private_key
        );

        $response = wp_remote_post( $endpoint, array(
            'body'    => json_encode( $body ),
            'headers' => array( 'Content-Type' => 'application/json' ),
            'timeout' => 30
        ));

        if ( is_wp_error( $response ) ) return $response;
        
        $raw = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );
        
        // Postman Response: { "access_token": "...", "expires_in": 7200, "code": "00", "message": "Success" }
        if ( isset( $data['code'] ) && $data['code'] === '00' && !empty( $data['access_token'] ) ) {
            set_transient( 'wc_9psb_access_token', $data['access_token'], ($data['expires_in'] ?? 3600) - 60 );
            return $data['access_token'];
        }
        
        return new WP_Error( 'auth_failed', '9PSB Auth Failed: ' . $raw );
    }

    public function generate_virtual_account( $order, $amount_ngn ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) return $token;

        $base_url = 'https://baastest.9psb.com.ng';
        $endpoint = "$base_url/iva-api/v1/merchant/virtualaccount/create";

        // Postman: { transaction: { reference }, order: { amount, currency, description, country, amounttype }, customer: { account: { name, type: DYNAMIC, expiry: { hours } } } }
        
        $ref = 'PSB-' . $order->get_id() . '-' . time();

        $body = array(
            'transaction' => array(
                'reference' => $ref
            ),
            'order' => array(
                'amount' => (int) $amount_ngn,
                'currency' => 'NGN',
                'description' => "Order " . $order->get_id() . " - " . substr($order->get_billing_first_name() . ' ' . $order->get_billing_last_name(), 0, 30),
                'country' => 'NGA',
                'amounttype' => 'EXACT'
            ),
            'customer' => array(
                'account' => array(
                    'name' => 'Checkout',
                    'type' => 'DYNAMIC',
                    'expiry' => array(
                        'hours' => 24
                    )
                )
            ),
            // 'beneficiarytocredit' ? Not in all requests, optional?
        );
        
        wc_get_logger()->info( "9PSB Request: " . json_encode($body), array('source' => '9psb') );

        $response = wp_remote_post( $endpoint, array(
            'body'    => json_encode( $body ),
            'headers' => array( 
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json' 
            ),
            'timeout' => 45
        ));

        if ( is_wp_error( $response ) ) return $response;
        
        $raw = wp_remote_retrieve_body( $response );
        wc_get_logger()->info( "9PSB Response: " . $raw, array('source' => '9psb') );
        
        $data = json_decode( $raw, true );

        // Response: { code: "00", message: "Success", transaction: {}, order: {}, customer: { account: { name, number, bank } } }
        if ( isset( $data['code'] ) && $data['code'] === '00' ) {
            $acc = $data['customer']['account'];
            return array(
                'bank_name'      => $acc['bank'] ?? '9PSB',
                'account_number' => $acc['number'],
                'account_name'   => $acc['name'],
                'reference'      => $data['transaction']['reference'] ?? $ref
            );
        }

        return new WP_Error( 'api_error', '9PSB Create Error: ' . $raw );
    }

    public function confirm_payment( $reference ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) return $token;

        $base_url = 'https://baastest.9psb.com.ng';
        $endpoint = "$base_url/iva-api/v1/merchant/virtualaccount/confirmpayment";
        // NOTE: Postman has `confirmpayment` (no underscore?) or `confirm`? 
        // Postman Item: "ConfirmVirtualPayment" -> url: .../confirmpayment
        
        // Body in Postman: { reference, sessionid="", amount, accountnumber }
        // BUT the endpoint might also support just reference?
        // Text Spec says: Payload { reference } -> Response { status: true, data: { status: PAID } }
        // Postman says: Payload { reference, ... } -> Response: { transactions: [ { message: Success, code: 00 } ], code: 00 }
        
        // I will implement based on PROMPT TEXT SPEC (simpler) but if that fails, we might need full Postman body.
        // Wait, text spec said "Rewritten for implementation".
        // Let's try the minimal payload first, or safer: include empty sessionid as in Postman.
        
        $body = array(
            'reference' => $reference
        );

        $response = wp_remote_post( $endpoint, array(
            'body'    => json_encode( $body ),
            'headers' => array( 
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json' 
            ),
            'timeout' => 30
        ));
        
        if ( is_wp_error( $response ) ) return $response;
        
        $raw = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );
        
        // Check Postman style response first (Code 00)
        if ( isset( $data['code'] ) && $data['code'] === '00' ) {
            // Check transactions array
            if ( !empty($data['transactions']) && $data['transactions'][0]['code'] === '00' ) {
                return true;
            }
        }
        
        // Check Text Spec style
        if ( isset( $data['status'] ) && $data['status'] === true && isset($data['data']['status']) && $data['data']['status'] === 'PAID' ) {
            return true;
        }
        
        return false;
    }

    public function verify_webhook( $request ) {
        // 1. Verify Basic Auth (The "Username" and "Password" User mentioned)
        if ( $this->webhook_username && $this->webhook_password ) {
            $user = $_SERVER['PHP_AUTH_USER'] ?? '';
            $pass = $_SERVER['PHP_AUTH_PW'] ?? '';
            
            // Fallback for headers if PHP_AUTH not set (common in some hosting)
            if ( ! $user ) {
                $auth_header = $request->get_header( 'authorization' );
                if ( $auth_header && strpos( strtolower($auth_header), 'basic' ) === 0 ) {
                    list($user, $pass) = explode( ':', base64_decode( substr( $auth_header, 6 ) ) );
                }
            }

            if ( $user !== $this->webhook_username || $pass !== $this->webhook_password ) {
                return new WP_Error( 'unauthorized', 'Invalid Webhook Credentials' );
            }
        }

        $body = $request->get_body();
        $data = json_decode( $body, true );
        
        $ref = $data['reference'] ?? '';
        if ( ! $ref ) return new WP_Error( 'invalid_payload', 'No reference' );

        // 2. Confirm Payment via API
        $confirmed = $this->confirm_payment( $ref );
        
        if ( $confirmed === true ) {
             return array(
                'status'    => 'paid',
                'amount'    => $data['amount'] ?? 0, // Ensure webhook sends amount or we need to trust order? API confirm is better.
                'reference' => $ref
             );
        }
        
        return new WP_Error( 'verification_failed', 'Could not confirm payment via API' );
    }
}
