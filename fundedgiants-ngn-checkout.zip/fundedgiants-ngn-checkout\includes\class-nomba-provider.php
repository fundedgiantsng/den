<?php
defined( 'ABSPATH' ) || exit;

class WC_Nomba_Provider implements WC_Lenco_Provider_Interface {
    private $client_id;
    private $client_secret; // Nomba calls this "Private Key" in the dashboard — same field
    private $account_id;
    private $environment;
    private $webhook_secret;
    private $base_url;

    public function __construct( $client_id, $client_secret, $account_id, $environment = 'live', $webhook_secret = '' ) {
        $this->client_id     = $client_id;
        $this->client_secret = $client_secret; // The "Private Key" from Nomba Dashboard
        $this->account_id    = $account_id;
        $this->environment   = $environment;
        $this->webhook_secret = $webhook_secret;
        $this->base_url = ( $environment === 'sandbox' )
            ? 'https://sandbox.nomba.com'
            : 'https://api.nomba.com';
    }

    public function get_id()   { return 'nomba'; }
    public function get_name() { return 'Nomba';  }

    /**
     * Step 1 – Get a short-lived access token using Client ID + Client Secret (= Private Key)
     * Endpoint: POST /v1/auth/token/issue
     */
    private function get_access_token( $force_refresh = false ) {
        // Return cached token if still valid
        $token = get_transient( 'wc_nomba_access_token' );
        if ( $token && ! $force_refresh ) {
            return $token;
        }

        $endpoint = $this->base_url . '/v1/auth/token/issue';

        // Body as documented: grant_type + client_id + client_secret
        $body = array(
            'grant_type'    => 'client_credentials',
            'client_id'     => $this->client_id,
            'client_secret' => $this->client_secret // Your Nomba "Private Key"
        );

        $logger = wc_get_logger();
        $logger->info(
            "Nomba Auth Request ({$this->environment}): POST {$endpoint} | accountId: {$this->account_id}",
            array( 'source' => 'nomba-payment' )
        );

        $response = wp_remote_post( $endpoint, array(
            'body'    => json_encode( $body ),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'accountId'    => $this->account_id,
            ),
            'timeout'   => 90,
            'sslverify' => true,
        ) );

        if ( is_wp_error( $response ) ) {
            $logger->error( "Nomba Auth WP Error: " . $response->get_error_message(), array( 'source' => 'nomba-payment' ) );
            return $response;
        }

        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        // Mask token in log
        $log_data = $data;
        if ( isset( $log_data['data']['access_token'] ) ) {
            $log_data['data']['access_token'] = '******';
        }
        $logger->info( "Nomba Auth Response: " . json_encode( $log_data ), array( 'source' => 'nomba-payment' ) );

        if ( isset( $data['code'] ) && $data['code'] === '00' && ! empty( $data['data']['access_token'] ) ) {
            $access_token = $data['data']['access_token'];
            // Cache for 55 minutes (tokens typically expire in 60 min)
            set_transient( 'wc_nomba_access_token', $access_token, 55 * MINUTE_IN_SECONDS );
            return $access_token;
        }

        $err_msg = $data['description'] ?? ( $data['message'] ?? $raw );
        if ( stripos( $err_msg, 'Client record not found' ) !== false || stripos( $err_msg, 'suspended' ) !== false ) {
            $err_msg .= '. Please ensure your Nomba API keys/Account ID match your dashboard and that your Corporate account has been activated for API access by Nomba.';
        }
        return new WP_Error( 'auth_failed', 'Nomba Auth Failed: ' . $err_msg );
    }

    /**
     * Step 2 – Create a one-time virtual account for this order
     * Endpoint: POST /v1/accounts/virtual (or Backend Bridge to FundedGiants API)
     */
    public function generate_virtual_account( $order, $amount_ngn, $retry = true ) {
        $raw_first = trim( $order->get_billing_first_name() );
        $raw_last  = trim( $order->get_billing_last_name() );
        $customer_full = trim( $raw_first . ' ' . $raw_last );
        if ( empty( $customer_full ) ) {
            $customer_full = 'Trader';
        }

        // Sanitise customer name
        $clean_customer = trim( preg_replace( '/\s+/', ' ',
            preg_replace( '/[^a-zA-Z0-9 ]/', ' ', $customer_full )
        ) );
        if ( empty( $clean_customer ) ) {
            $clean_customer = 'Trader';
        }

        // FG-UPDATE: Delegate to FundedGiants Backend Bridge if credentials missing or local auth fails
        if ( empty( $this->client_id ) || empty( $this->account_id ) ) {
            return $this->call_backend_bridge( $order, $amount_ngn, $clean_customer );
        }

        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) {
            // FG-UPDATE: Automatic failover to Backend CRM Nomba Bridge if local credentials fail
            $logger = wc_get_logger();
            $logger->warning( "Nomba local auth failed (" . $token->get_error_message() . "). Failing over to Backend CRM Nomba Bridge...", array( 'source' => 'nomba-payment' ) );
            return $this->call_backend_bridge( $order, $amount_ngn, $clean_customer );
        }

        $endpoint = $this->base_url . '/v1/accounts/virtual';
        $ref      = 'NMB' . $order->get_id() . 'T' . time();

        // Account Name format: Customer First and Last Name
        // (Nomba automatically prepends/appends the registered business name 'FundedGiants' at the bank)
        $clean_account_name = substr( $clean_customer, 0, 80 );

        $body = array(
            'accountRef'     => $ref,
            'accountName'    => $clean_account_name,
            'currency'       => 'NGN',
            'expectedAmount' => (float) $amount_ngn,
            'expiryDate'     => gmdate( 'Y-m-d\TH:i:s\Z', strtotime( '+24 hours' ) ),
            'customerEmail'  => $order->get_billing_email(),
            'customerName'   => $clean_customer,
        );

        $headers = array(
            'Authorization' => 'Bearer ' . $token,
            'accountId'     => $this->account_id,
            'Content-Type'  => 'application/json',
        );

        $logger = wc_get_logger();
        $logger->info(
            "Nomba VA Request ({$this->environment}): " . json_encode( $body ),
            array( 'source' => 'nomba-payment' )
        );

        $response = wp_remote_post( $endpoint, array(
            'body'      => json_encode( $body ),
            'headers'   => $headers,
            'timeout'   => 120,
            'sslverify' => true,
        ) );

        if ( is_wp_error( $response ) ) {
            $logger->error( "Nomba VA WP Error: " . $response->get_error_message(), array( 'source' => 'nomba-payment' ) );
            return $response;
        }

        $http_code = (int) wp_remote_retrieve_response_code( $response );
        $raw       = wp_remote_retrieve_body( $response );
        $logger->info( "Nomba VA Response ({$http_code}): " . $raw, array( 'source' => 'nomba-payment' ) );

        // Auto-retry once on token expiry signals
        if ( in_array( $http_code, array( 401, 403 ), true ) && $retry ) {
            $logger->warning( "Nomba token may be expired ({$http_code}). Refreshing and retrying once…", array( 'source' => 'nomba-payment' ) );
            $this->get_access_token( true );
            return $this->generate_virtual_account( $order, $amount_ngn, false );
        }

        $data = json_decode( $raw, true );

        if ( isset( $data['code'] ) && $data['code'] === '00' ) {
            $acc = $data['data'];

            // Return bankAccountName from Nomba (or accountName), ensuring no 'Checkout' placeholder
            $returned_name = ! empty( $acc['bankAccountName'] ) ? $acc['bankAccountName'] : ( ! empty( $acc['accountName'] ) ? $acc['accountName'] : '' );
            if ( empty( $returned_name ) || strcasecmp( trim( $returned_name ), 'Checkout' ) === 0 ) {
                $returned_name = $clean_customer;
            }

            return array(
                'bank_name'      => $acc['bankName']          ?? 'Nomba',
                'account_number' => $acc['bankAccountNumber'] ?? ( $acc['accountNumber'] ?? '' ),
                'account_name'   => $returned_name,
                'reference'      => $acc['accountRef'],
            );
        }

        $err_msg = $data['description'] ?? ( $data['message'] ?? $raw );
        return new WP_Error( 'api_error', 'Nomba Create Error: ' . $err_msg );
    }

    /**
     * FG-UPDATE: Fallback Backend Nomba Bridge
     * Calls FundedGiants API to generate a verified Nomba Virtual Account
     */
    public function call_backend_bridge( $order, $amount_ngn, $clean_customer ) {
        $backend_api_url = defined( 'FUNDEDGIANTS_API_URL' ) ? FUNDEDGIANTS_API_URL : get_option( 'fg_backend_api_url', 'https://api.fundedgiants.ng' );
        $bridge_endpoint = rtrim( $backend_api_url, '/' ) . '/api/v1/webhooks/nomba/create-order-account';

        $logger = wc_get_logger();
        $logger->info( "Calling FundedGiants Backend Nomba Bridge: {$bridge_endpoint} for Order #{$order->get_id()}", array( 'source' => 'nomba-payment' ) );

        $bridge_res = wp_remote_post( $bridge_endpoint, array(
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => json_encode( array(
                'orderId'      => $order->get_id(),
                'amount'       => (float) $amount_ngn,
                'customerName' => $clean_customer,
                'email'        => $order->get_billing_email(),
            ) ),
            'timeout' => 45,
        ) );

        if ( ! is_wp_error( $bridge_res ) && wp_remote_retrieve_response_code( $bridge_res ) === 200 ) {
            $bData = json_decode( wp_remote_retrieve_body( $bridge_res ), true );
            if ( ! empty( $bData['account_number'] ) ) {
                return array(
                    'bank_name'      => $bData['bank_name'] ?? 'Nomba',
                    'account_number' => $bData['account_number'],
                    'account_name'   => $bData['account_name'] ?? $clean_customer,
                    'reference'      => $bData['reference'],
                );
            }
        }

        $err_details = is_wp_error( $bridge_res ) ? $bridge_res->get_error_message() : wp_remote_retrieve_body( $bridge_res );
        $logger->error( "Backend Bridge Error: " . $err_details, array( 'source' => 'nomba-payment' ) );
        return new WP_Error( 'bridge_failed', 'Nomba Virtual Account creation unavailable. Please contact support@fundedgiants.ng.' );
    }

    /**
     * Fetch a virtual account by reference
     */
    public function fetch_virtual_account( $identifier ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) return $token;

        $endpoint = $this->base_url . '/v1/accounts/virtual/' . urlencode( $identifier );

        $response = wp_remote_get( $endpoint, array(
            'headers'   => array(
                'Authorization' => 'Bearer ' . $token,
                'accountId'     => $this->account_id,
            ),
            'timeout'   => 90,
            'sslverify' => true,
        ) );

        if ( is_wp_error( $response ) ) return $response;
        return json_decode( wp_remote_retrieve_body( $response ), true );
    }

    /**
     * Webhook verification (HMAC-SHA256 + Base64, raw body HMAC, direct secret match, or Nomba API active confirmation)
     */
    public function verify_webhook( $request ) {
        $sig       = $request->get_header( 'nomba-signature' ) 
                  ?: $request->get_header( 'x-nomba-signature' ) 
                  ?: $request->get_header( 'nomba-sig-value' );
        $timestamp = $request->get_header( 'nomba-timestamp' );
        $body      = $request->get_body();
        $logger    = wc_get_logger();

        $data = json_decode( $body, true );
        if ( ! $data ) {
            $logger->error( "Nomba Webhook: Invalid JSON payload.", array( 'source' => 'nomba-payment' ) );
            return new WP_Error( 'invalid_payload', 'Invalid JSON' );
        }

        $is_verified = false;

        $proxy_header = $request->get_header( 'x-nomba-proxy' );
        if ( $proxy_header === 'FundedGiants-Internal' ) {
            $is_verified = true;
        }

        // 1. Dual-Secret verification: Test both Webhook Secret and Client Secret across encodings
        $candidate_secrets = array_filter( array_unique( array( $this->webhook_secret, $this->client_secret ) ) );
        if ( ! $is_verified && ! empty( $candidate_secrets ) && ! empty( $sig ) ) {
            foreach ( $candidate_secrets as $secret ) {
                if ( hash_equals( $secret, $sig ) ) {
                    $is_verified = true;
                    break;
                }

                $rawHex = hash_hmac( 'sha256', $body, $secret );
                $rawBase64 = base64_encode( hash_hmac( 'sha256', $body, $secret, true ) );
                if ( hash_equals( $rawHex, $sig ) || hash_equals( $rawBase64, $sig ) ) {
                    $is_verified = true;
                    break;
                }

                if ( ! empty( $timestamp ) ) {
                    $event_type     = $data['event_type']                              ?? '';
                    $request_id     = $data['requestId']                               ?? '';
                    $user_id        = $data['data']['merchant']['userId']              ?? '';
                    $wallet_id      = $data['data']['merchant']['walletId']            ?? '';
                    $transaction_id = $data['data']['transaction']['transactionId']    ?? '';
                    $type           = $data['data']['transaction']['type']             ?? '';
                    $time           = $data['data']['transaction']['time']             ?? '';
                    $response_code  = $data['data']['transaction']['responseCode']     ?? '';
                    if ( $response_code === 'null' || $response_code === null ) $response_code = '';

                    $hashing_payload = "{$event_type}:{$request_id}:{$user_id}:{$wallet_id}:{$transaction_id}:{$type}:{$time}:{$response_code}:{$timestamp}";
                    $expectedBase64  = base64_encode( hash_hmac( 'sha256', $hashing_payload, $secret, true ) );
                    $expectedHex     = hash_hmac( 'sha256', $hashing_payload, $secret );

                    if ( hash_equals( $expectedBase64, $sig ) || hash_equals( $expectedHex, $sig ) ) {
                        $is_verified = true;
                        break;
                    }
                }
            }
        }

        // 2. Direct API verification fallback if signature matching failed
        if ( ! $is_verified ) {
            $ref = $data['data']['transaction']['aliasAccountReference'] ?? ( $data['data']['accountRef'] ?? '' );
            if ( ! empty( $ref ) ) {
                $logger->info( "Nomba Webhook: Verifying reference {$ref} directly via Nomba live API...", array( 'source' => 'nomba-payment' ) );
                $apiCheck = $this->confirm_payment( $ref );
                if ( $apiCheck ) {
                    $is_verified = true;
                    $logger->info( "Nomba Webhook: Direct API confirmation successful for {$ref}.", array( 'source' => 'nomba-payment' ) );
                }
            }
        }

        if ( ! $is_verified ) {
            $logger->error( "Nomba Webhook Signature mismatch & API check failed.", array( 'source' => 'nomba-payment' ) );
            return new WP_Error( 'forbidden', 'Invalid Nomba Signature' );
        }

        $logger->info( "Nomba Webhook Verified: " . $body, array( 'source' => 'nomba-payment' ) );

        $event_type = $data['event_type'] ?? '';
        $status     = strtolower( $data['data']['transaction']['responseCode'] ?? '' );
        if ( strtolower( $event_type ) === 'payment_success' || $status === '00' ) {
            return array(
                'status'         => 'paid',
                'amount'         => $data['data']['transaction']['transactionAmount']    ?? ( $data['data']['amount'] ?? 0 ),
                'reference'      => $data['data']['transaction']['aliasAccountReference'] ?? ( $data['data']['accountRef'] ?? '' ),
                'account_number' => $data['data']['transaction']['aliasAccountNumber'] ?? ( $data['data']['transaction']['accountNumber'] ?? ( $data['data']['account']['bankAccountNumber'] ?? ( $data['data']['bankAccountNumber'] ?? '' ) ) ),
            );
        }

        return new WP_Error( 'verification_failed', 'Nomba Payment Event: ' . $event_type );
    }

    public function confirm_payment( $reference ) {
        $data = $this->fetch_virtual_account( $reference );
        return ( isset( $data['code'] ) && $data['code'] === '00' );
    }
}
