<?php
defined( 'ABSPATH' ) || exit;

class WC_Lenco_Provider implements WC_Lenco_Provider_Interface {
    private $bearer_token;

    public function __construct( $bearer_token ) {
        $this->bearer_token = $bearer_token;
    }

    public function get_id() {
        return 'lenco';
    }

    public function get_name() {
        return 'Lenco';
    }

    public function generate_virtual_account( $order, $amount_ngn ) {
        $endpoint = 'https://api.lenco.co/access/v1/virtual-accounts';
        
        $logger = wc_get_logger();
        $log_context = array( 'source' => 'lenco-payment' );
        
        // Generate Custom Reference: lco + ORDERID + TIMESTAMP (HHMMSS in WAT)
        // WAT is UTC+1. We use DateTime to ensure accuracy.
        try {
            $date = new DateTime('now', new DateTimeZone('Africa/Lagos'));
        } catch (Exception $e) {
            $date = new DateTime('now', new DateTimeZone('UTC'));
            $date->modify('+1 hour'); // Fallback estimate for WAT
        }
        $time_str = $date->format('His'); // Limit to 6 chars (HHMMSS)
        
        // Ref Format: lco + OrderID + HHMMSS 
        // Example: Order 12345 at 16:30:45 -> lco12345163045
        // This acts as a unique reference allowing retries
        $ref = 'lco' . $order->get_id() . $time_str;

        $raw_first = trim( $order->get_billing_first_name() );
        $raw_last  = trim( $order->get_billing_last_name() );
        $customer_full = trim( $raw_first . ' ' . $raw_last );
        if ( empty( $customer_full ) ) {
            $customer_full = 'Trader';
        }
        $clean_customer = trim( preg_replace( '/\s+/', ' ', preg_replace( '/[^a-zA-Z0-9 ]/', '', $customer_full ) ) );
        $account_name   = substr( $clean_customer, 0, 80 );

        $body = array(
            'accountName' => $account_name,
            'email'       => $order->get_billing_email(),
            'amount'      => (float) $amount_ngn,
            'minAmount'   => (float) $amount_ngn,
            'transactionReference' => $ref, 
            'createNewAccount' => true
        );
        
        $logger->info( "Sending Request to Lenco for Order " . $order->get_id(), $log_context );

        $response = wp_remote_post( $endpoint, array(
            'body'    => json_encode( $body ),
            'headers' => array( 'Authorization' => 'Bearer ' . $this->bearer_token, 'Content-Type' => 'application/json' ),
            'timeout' => 45
        ));

        if ( is_wp_error( $response ) ) {
            $logger->error( "HTTP Error: " . $response->get_error_message(), $log_context );
            return $response;
        }
        
        $raw_body = wp_remote_retrieve_body( $response );
        $logger->info( "Lenco Response Received.", $log_context );
        
        $data = json_decode( $raw_body, true );
        
        if ( isset( $data['status'] ) && $data['status'] === false ) {
             $msg = $data['message'] ?? 'Unknown Lenco Error';
             return new WP_Error( 'api', 'Lenco API Error: ' . $msg );
        }

        if ( isset( $data['data'] ) ) {
            $d = $data['data'];
            if( isset($d['bankAccount']) ) {
                return array(
                    'bank_name'      => $d['bankAccount']['bank']['name'] ?? 'Lenco Bank',
                    'account_number' => $d['bankAccount']['accountNumber'] ?? '',
                    'account_name'   => $d['bankAccount']['accountName'] ?? '',
                    'reference'      => $d['meta']['transactionReference'] ?? $d['transactionReference'] ?? $order->get_id(),
                );
            }
        } 
        
        return new WP_Error( 'api', 'Lenco API Error: Could not find bankAccount. Response: ' . substr($raw_body, 0, 200) );
    }

    public function verify_webhook( $request ) {
        $sig  = $request->get_header( 'x-lenco-signature' );
        $body = $request->get_body();
        
        if ( empty( $sig ) || ! $this->bearer_token || ! hash_equals( hash_hmac('sha256', $body, $this->bearer_token), (string) $sig ) ) {
            return new WP_Error( 'forbidden', 'Invalid Signature' );
        }

        $data = json_decode( $body, true );
        $payload = $data['data'] ?? $data;
        
        $status = strtolower( $payload['status'] ?? '' );
        if ( $status == 'success' || $status == 'successful' ) {
            return array(
                'status' => 'paid',
                'amount' => $payload['amount'] ?? 0,
                'reference' => $payload['reference'] ?? ($payload['transactionReference'] ?? ''),
            );
        }

        return new WP_Error( 'invalid_status', 'Status not success' );
    }

    public function confirm_payment( $reference ) {
         // Lenco doesn't have a confirm endpoint in the same way 9PSB does, or it wasn't used in legacy. 
         // We rely on webhook for Lenco.
         return true;
    }
}
