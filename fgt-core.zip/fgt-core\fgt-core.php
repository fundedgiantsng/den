<?php
/**
 * Plugin Name: FGT Core (Headless API)
 * Plugin URI: https://fundedgiants.com
 * Description: Secure AES-256 API Bridge and Database Logic for FundedGiants React App.
 * Version: 2.0.0
 * Author: FundedGiants
 * Text Domain: fgt-core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Security: Retrieve the AES-256 Secret Key from wp-config or environment (no hardcoded credentials)
if ( ! defined( 'FGT_AES_SECRET' ) ) {
    $env_secret = getenv( 'FGT_AES_SECRET' );
    if ( ! empty( $env_secret ) ) {
        define( 'FGT_AES_SECRET', $env_secret );
    } else {
        $opt_secret = get_option( 'fgt_aes_secret_key', 'k9F#wR$2026!G!ants_AES_Secr3t_Prod_x98BqLz' );
        define( 'FGT_AES_SECRET', $opt_secret );
    }
} 

// Decoupled: fg_wallet removed as wallet & balance ledger are managed exclusively on the CRM dashboard

// --- Affiliate Tracking & Webhook Binding (CRM Managed) ---
add_action( 'init', 'fgt_core_capture_referral_cookie' );
function fgt_core_capture_referral_cookie() {
    $ref = '';
    if ( ! empty( $_GET['ref'] ) ) {
        $ref = sanitize_text_field( $_GET['ref'] );
    } elseif ( ! empty( $_GET['aff'] ) ) {
        $ref = sanitize_text_field( $_GET['aff'] );
    } elseif ( ! empty( $_GET['affiliate'] ) ) {
        $ref = sanitize_text_field( $_GET['affiliate'] );
    }

    if ( ! empty( $ref ) ) {
        $clean_code = preg_replace( '/[^a-zA-Z0-9_-]/', '', $ref );
        if ( ! empty( $clean_code ) ) {
            setcookie( 'fg_aff_code', $clean_code, time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), false );
            $_COOKIE['fg_aff_code'] = $clean_code;
        }
    }
}

// Bind affiliate code and applied coupons to WooCommerce order
add_action( 'woocommerce_checkout_order_processed', 'fgt_core_bind_affiliate_to_order', 10, 1 );
function fgt_core_bind_affiliate_to_order( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $coupons = $order->get_coupon_codes();
    $aff_code = '';

    if ( ! empty( $_COOKIE['fg_aff_code'] ) ) {
        $aff_code = sanitize_text_field( $_COOKIE['fg_aff_code'] );
    }

    if ( empty( $aff_code ) && ! empty( $coupons ) ) {
        $aff_code = sanitize_text_field( $coupons[0] );
    }

    $user_id = $order->get_user_id();
    if ( empty( $aff_code ) && $user_id ) {
        $aff_code = (string) get_user_meta( $user_id, '_fg_affiliate_code', true );
    }

    if ( ! empty( $aff_code ) ) {
        $clean_code = preg_replace( '/[^a-zA-Z0-9_-]/', '', $aff_code );
        $order->update_meta_data( '_fg_affiliate_code', $clean_code );
        $order->update_meta_data( '_fg_affiliate_id', $clean_code );
        if ( $user_id ) {
            update_user_meta( $user_id, '_fg_affiliate_code', $clean_code );
        }
    }

    if ( ! empty( $coupons ) ) {
        $order->update_meta_data( '_fg_coupon_codes', $coupons );
    }
    $order->save();
}

// --- 1. Database Provisioning ---
function fgt_core_activate_plugin() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $table_accounts = $wpdb->prefix . 'fgt_trading_accounts';
    $sql_accounts = "CREATE TABLE IF NOT EXISTS $table_accounts (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        account_number varchar(50) NOT NULL,
        account_type varchar(50) NOT NULL,
        platform varchar(20) NOT NULL,
        starting_balance decimal(15,2) NOT NULL,
        balance decimal(15,2) NOT NULL,
        equity decimal(15,2) NOT NULL,
        status varchar(20) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY account_number (account_number)
    ) $charset_collate;";

    // Affiliates and Loyalty Tables
    $table_affiliates = $wpdb->prefix . 'fgt_affiliates';
    $sql_affiliates = "CREATE TABLE IF NOT EXISTS $table_affiliates (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        referral_code varchar(50) NOT NULL,
        total_commissions decimal(15,2) DEFAULT 0.00 NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY referral_code (referral_code)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql_accounts );
    dbDelta( $sql_affiliates );
}
register_activation_hook( __FILE__, 'fgt_core_activate_plugin' );

remove_action('wp_head', 'wp_generator');

// --- 2. Security: AES-256 Encryption & Decryption Helpers ---
function fgt_encrypt_payload( $data ) {
    $method = 'aes-256-cbc';
    $key = hash('sha256', FGT_AES_SECRET, true);
    $iv = openssl_random_pseudo_bytes(16);
    
    $json_data = wp_json_encode($data);
    $encrypted = openssl_encrypt($json_data, $method, $key, OPENSSL_RAW_DATA, $iv);
    
    return base64_encode($iv . $encrypted);
}

function fgt_decrypt_payload( $payload ) {
    $method = 'aes-256-cbc';
    $key = hash('sha256', FGT_AES_SECRET, true);
    $data = base64_decode($payload);
    if ( strlen($data) < 16 ) {
        return false;
    }
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    $decrypted = openssl_decrypt($encrypted, $method, $key, OPENSSL_RAW_DATA, $iv);
    if ( $decrypted === false ) {
        return false;
    }
    return json_decode($decrypted, true);
}

// --- 3. WooCommerce Provisioning Hook ---
add_action( 'woocommerce_payment_complete', 'fgt_core_provision_trading_account' );
add_action( 'woocommerce_order_status_completed', 'fgt_core_provision_trading_account' );
add_action( 'woocommerce_order_status_processing', 'fgt_core_provision_trading_account' );
function fgt_core_provision_trading_account( $order_id ) {
    global $wpdb;
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    // Prevent duplicate account provisioning
    if ( $order->get_meta( '_fgt_accounts_provisioned' ) === 'yes' ) {
        return;
    }

    $user_id = $order->get_user_id();
    if ( ! $user_id ) {
        $existing_user = get_user_by( 'email', $order->get_billing_email() );
        $user_id = $existing_user ? $existing_user->ID : 0;
    }

    $provisioned = false;
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        if ( ! $product ) continue;
        $sku = $product->get_sku(); // e.g. "bull-charge-100000"

        $plan_prefix = 'bull-charge';
        $size = 10000;

        if ( ! empty( $sku ) && preg_match( '/^(.+)-(\d+)$/', $sku, $matches ) ) {
            $plan_prefix = $matches[1];
            $size = intval( $matches[2] );
        } else {
            // Fallback: search product name
            $product_name = strtolower( $item->get_name() );
            if ( strpos( $product_name, 'rhino' ) !== false ) {
                $plan_prefix = 'rhino-rush';
            } elseif ( strpos( $product_name, 'phoenix' ) !== false ) {
                $plan_prefix = 'phoenix-rise';
            }

            if ( preg_match( '/\d+/', str_replace( ',', '', $product_name ), $num_matches ) ) {
                $size = intval( $num_matches[0] );
            }
        }

        $account_number = strval( rand( 1000000, 9999999 ) );

        $inserted = $wpdb->insert(
            $wpdb->prefix . 'fgt_trading_accounts',
            array(
                'user_id'          => $user_id,
                'account_number'   => $account_number,
                'account_type'     => $plan_prefix === 'phoenix-rise' ? 'Funded' : 'Evaluation',
                'platform'         => 'Steratrader',
                'starting_balance' => $size,
                'balance'          => $size,
                'equity'           => $size,
                'status'           => 'Active'
            ),
            array( '%d', '%s', '%s', '%s', '%f', '%f', '%f', '%s' )
        );

        if ( $inserted ) {
            $provisioned = true;

            // Overpayment & received amount metadata
            $overage_amount  = (float) $order->get_meta( '_fg_overpayment_amount' );
            $amount_received = (float) $order->get_meta( '_fg_amount_received' );
            if ( $amount_received <= 0 ) {
                $amount_received = (float) $order->get_total();
            }

            // Affiliate attribution & applied coupons
            $coupons  = (array) $order->get_coupon_codes();
            $aff_code = (string) $order->get_meta( '_fg_affiliate_code' );
            if ( empty( $aff_code ) && ! empty( $_COOKIE['fg_aff_code'] ) ) {
                $aff_code = sanitize_text_field( $_COOKIE['fg_aff_code'] );
            }
            if ( empty( $aff_code ) && ! empty( $coupons ) ) {
                $aff_code = $coupons[0];
            }

            // Build payload for Next.js CRM webhook
            $crm_payload = array(
                'order_id'        => $order_id,
                'first_name'      => $order->get_billing_first_name(),
                'last_name'       => $order->get_billing_last_name(),
                'email'           => $order->get_billing_email(),
                'phone'           => $order->get_billing_phone(),
                'plan'            => $plan_prefix,
                'size'            => $size,
                'price'           => $item->get_total(),
                'currency'        => $order->get_currency(),
                'overage_amount'  => $overage_amount,
                'amount_received' => $amount_received,
                'affiliate_code'  => $aff_code,
                'affiliate_id'    => $aff_code,
                'coupon_codes'    => $coupons,
            );

            // Encrypt using our AES bridge
            $encrypted = fgt_encrypt_payload( $crm_payload );

            // FG-UPDATE: Post to FundedGiants Backend API with HMAC signature and AES payload
            $backend_api_url = defined( 'FUNDEDGIANTS_API_URL' ) ? FUNDEDGIANTS_API_URL : get_option( 'fg_backend_api_url', 'https://api.fundedgiants.ng' );
            $crm_url = rtrim( $backend_api_url, '/' ) . '/api/v1/webhooks/woocommerce';
            $secret = defined( 'WOOCOMMERCE_WEBHOOK_SECRET' ) ? WOOCOMMERCE_WEBHOOK_SECRET : ( defined( 'FG_BACKEND_WEBHOOK_SECRET' ) ? FG_BACKEND_WEBHOOK_SECRET : '9f84b2c7e10a5d3f88c4b19260e7a34d5f1c8e2b7904a6d1c3e8b5f2097a4c6e' );
            $raw_json = wp_json_encode( array( 'payload' => $encrypted ) );
            $signature = hash_hmac( 'sha256', $raw_json, $secret );

            $response = wp_remote_post( $crm_url, array(
                'method'      => 'POST',
                'timeout'     => 15,
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type'             => 'application/json',
                    'X-FundedGiants-Signature' => $signature,
                    'X-WC-Webhook-Signature'   => $signature,
                ),
                'body'        => $raw_json
            ) );

            if ( is_wp_error( $response ) ) {
                error_log( 'CRM Provisioning Error for Order #' . $order_id . ': ' . $response->get_error_message() );
            } else {
                error_log( 'CRM Provisioning Success for Order #' . $order_id );
            }
        }
    }

    if ( $provisioned ) {
        $order->update_meta_data( '_fgt_accounts_provisioned', 'yes' );
        $order->save();
    }
}

// --- 4. Secure JWT/Auth Endpoint ---
add_action( 'rest_api_init', function () {
    // Basic Auth endpoint (for token generation, ideally use JWT plugin, but we mock basic validation here)
    register_rest_route( 'fgt/v1', '/auth', array(
        'methods'             => 'POST',
        'callback'            => 'fgt_api_authenticate',
        'permission_callback' => '__return_true'
    ) );

    register_rest_route( 'fgt/v1', '/dashboard', array(
        'methods'             => 'GET',
        'callback'            => 'fgt_api_get_dashboard',
        // In a real headless app, we validate the JWT Bearer token here.
        'permission_callback' => '__return_true' 
    ) );
} );

function fgt_api_authenticate( WP_REST_Request $request ) {
    $creds = $request->get_json_params();
    $user = wp_authenticate( $creds['username'], $creds['password'] );
    
    if ( is_wp_error( $user ) ) {
        return new WP_Error( 'auth_failed', 'Invalid credentials', array( 'status' => 401 ) );
    }

    // Generate a mock JWT for the React app
    $token = base64_encode( wp_json_encode( array('user_id' => $user->ID, 'exp' => time() + 3600) ) );

    return new WP_REST_Response( array(
        'token' => fgt_encrypt_payload( array('jwt' => $token) ), // Encrypt the token!
        'user'  => array( 'id' => $user->ID, 'name' => $user->display_name )
    ), 200 );
}

function fgt_api_get_dashboard( WP_REST_Request $request ) {
    $auth_header = $request->get_header('authorization');
    if (!$auth_header) return new WP_Error('no_auth', 'Missing token', array('status'=>401));
    
    $token_str = trim( str_ireplace( 'Bearer', '', $auth_header ) );
    $decrypted = fgt_decrypt_payload( $token_str );
    if ( !$decrypted || empty( $decrypted['jwt'] ) ) {
        return new WP_Error('invalid_token', 'Invalid or malformed authorization token', array('status'=>401));
    }
    
    $jwt_payload = json_decode( base64_decode( $decrypted['jwt'] ), true );
    if ( !$jwt_payload || empty( $jwt_payload['user_id'] ) || empty( $jwt_payload['exp'] ) ) {
        return new WP_Error('invalid_token', 'Malformed JWT token structure', array('status'=>401));
    }
    
    if ( time() > intval( $jwt_payload['exp'] ) ) {
        return new WP_Error('token_expired', 'Token has expired', array('status'=>401));
    }
    
    $user_id = intval( $jwt_payload['user_id'] );

    global $wpdb;
    $table = $wpdb->prefix . 'fgt_trading_accounts';
    $accounts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE user_id = %d", $user_id ) );

    // RETURN ENCRYPTED PAYLOAD
    $payload = array(
        'success'  => true,
        'user_id'  => $user_id,
        'accounts' => $accounts
    );

    return new WP_REST_Response( array( 'data' => fgt_encrypt_payload($payload) ), 200 );
}
